<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "datamahasiswa";
$conn = mysqli_connect($host,$user,$password,$database);
if ($conn) {
    // echo "koneksi  berhasil<br>";
} else {
    // echo "koneksi gagal";
}
?>
